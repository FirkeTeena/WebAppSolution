# Web-App
This is a web app which contains back-end server, Angular UI and Cross Platform mobile app made using Ionic. This project deals with user login,signup,profile,etc
